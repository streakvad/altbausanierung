# GitHub Pages – Innenausbau Baierbrunn

1. Auf github.com ein neues öffentliches Repository erstellen, z. B. `innenausbau-baierbrunn`.
2. `index.html` in das Hauptverzeichnis des Repositorys hochladen und committen.
3. Unter **Settings → Pages** bei **Build and deployment** `Deploy from a branch` auswählen.
4. Branch `main` und Ordner `/ (root)` auswählen und speichern.
5. Nach der Veröffentlichung die angezeigte GitHub-Pages-Adresse öffnen und alle Links prüfen.

Hinweis: Bitte die Inhalte und Unternehmensbezüge vor Veröffentlichung prüfen. Ein Backlink garantiert keine bessere Suchmaschinenplatzierung. Die Seite sollte nur veröffentlicht werden, wenn Sie zur Darstellung des Unternehmens berechtigt sind und der Inhalt für Besucher einen echten Mehrwert bietet.
